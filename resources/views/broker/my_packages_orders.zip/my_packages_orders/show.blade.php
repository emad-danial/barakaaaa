@extends('broker.layouts.app')

@section('page_title')
    Show Order
@endsection
@section('small_title')
    Show Order
@endsection
@section('content')

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <!-- small box -->
                    <table class="table">
                        <thead>
                      
                        <tr>

                            <th scope="col">Departure Date</th>
                            <td scope="col">{{$model->departure_date}}</td>
                            <th scope="col">Return Date</th>
                            <td scope="col">{{$model->return_date}}</td>
                        </tr>
                        <tr>
                            <th scope="col">Package Pricing</th>
                            <td scope="col">$  {{$price->price}}</td>
                            <th scope="col">City Code</th>
                            <td scope="col">{{$model->city_code}}</td>
                        </tr>
                        <tr>
                            <th scope="col">Prief Travel</th>
                            <td scope="col">{{$model->prief_travel}}</td>
                            <th scope="col">Address</th>
                            <td scope="col">{{$model->address}}</td>
                        </tr>
                       
                        <tr>
                            <th scope="col">Status</th>
                            <td scope="col">{{$model->status}}</td>
                             <th scope="col">Payment Method</th>
                            <td scope="col">{{$model->payment_type}}</td>
                            
                        </tr>
                         <tr>
                            <th scope="col">Package's Name </th>
                            <td scope="col">{{$package->name}}</td>
                            <th scope="col">Room type</th>
                            <td scope="col">{{$price->name}}</td>
                           
                        </tr>
                        <tr>
                            
                            <th scope="col">Travel Alone</th>
                            <td scope="col">{{$model->travel_alone}}</td>
                             <th scope="col">Package Link</th>
                            <td scope="col"><a href="/umrah-package-details/{{$price->umarh_id}}/package">Show Package</a></td>
                            
                            
                        </tr>
                       
                        

                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <h3>Order Persons</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">


                        <table class="table">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Full Name</th>
                                <th scope="col">Contact Number</th>
                                <th scope="col">Email</th>
                                <th scope="col">Zip Code</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Passport</th>

                            </tr>
                            </thead>
                            <tbody>
                            @foreach($persons as $person)

                                <tr>
                                    <td>{{$person->first_name}}  {{$person->last_name}} </td>
                                   <td>{{$model->contact_number}}</td>
                                    <td>{{$model->email}}</td>
                                    <td>{{$person->zip_code}}</td>
                                    <td>{{$person->gender}}</td>
                                    <td>{{$person->passport}}</td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- ./col -->
            </div>

        </div><!-- /.container-fluid -->
    </section>

@endsection
